const Details = ({ contacts }) => {
  //const { contact } = contacts;
  console.log(contacts);
  return <li>{}</li>;
};

export default Details;
